/*
 * Procesamiento de Formatos en Aplicaciones Telemáticas
 * Práctica 1
 * 
 * Rodrigo De Lama Fernández - 100451775
 * Isabel Schweim - 100460211
 * 
 * Statement3.java
 */

package AST;

public class Statement3 implements Statement {
    public final String identifier;

    public Statement3(String identifier) {
        this.identifier = identifier;
    }
}
